<!--div class="sidebar app-aside" id="sidebar" style="background-color:aliceblue;">
				<div class="sidebar-container perfect-scrollbar" style="background-color:#444;">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU >
						<div class="sidebar-header">
							<img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo">
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="book-appointment.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Book Appointment </span>
										</div>
									</div>
								</a>
							</li>

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Appointment History </span>
										</div>
									</div>
								</a>
							</li>
<li>
								<a href="manage-medhistory.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Medical History </span>
										</div>
									</div>
								</a>
							</li>

						</ul>
						<!-- end: CORE FEATURES >
						
					</nav>
					</div>
			</div-->
		<nav id="sidebar" class="active" style="background-color: #000">
            <div class="sidebar-header" style="background-color: #000">
                <!--img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo"-->
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                </li>
                <li>
                    <a href="book-appointment.php"><i class="fas fa-file-alt"></i>  Book Appointment </a>
                </li>
                <li>
                    <a href="appointment-history.php"><i class="fas fa-table"></i> Appointment History </a>
                </li>
				<li>
                    <a href="view-medhistory.php"><i class="fas fa-table"></i> Medical History </a>
                </li>
				<li>
                    <a href="book-room.php"><i class="fas fa-bed"></i> Book Room </a>
                </li>
            </ul>
        </nav>