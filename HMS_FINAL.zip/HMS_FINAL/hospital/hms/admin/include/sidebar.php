		<nav id="sidebar" class="active" style="background-color: #000">
            <div class="sidebar-header" style="background-color: #000">
                <!--img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo"-->
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                </li>
                <li>
					<a href="javascript:void(0)">
						<i class="fas fa-user"></i>
						<span class="title"> Users </span><i class="icon-arrow"></i>
					</a>
					<ul class="sub-menu" style="background-color: #000">
						<li>
							<a href="add-user.php" style="background-color: #000">
							<i class="fas fa-plus-square"></i>
								<span class="title"> Add User</span>
							</a>
						</li>
						<li>
							<a href="manage-users.php" style="background-color: #000">
							<i class="fas fa-file-alt"></i>
								<span class="title"> Manage Users </span>
							</a>
						</li>
					</ul>
                </li>
				<li>
					<a href="javascript:void(0)">
						<i class="fas fa-user-md"></i>
						<span class="title"> Doctors </span><i class="icon-arrow"></i>
					</a>
					<ul class="sub-menu" style="background-color: #000">
						<li >
							<a href="doctor-specilization.php" style="background-color: #000" >
							<i class="fas fa-stethoscope"></i>
								<span class="title" > Specialization </span>
							</a>
						</li>
						<li>
							<a href="add-doctor.php" style="background-color: #000">
							<i class="fas fa-plus-square"></i>
								<span class="title"> Add Doctor</span>
							</a>
						</li>
						<li>
							<a href="manage-doctors.php" style="background-color: #000">
							<i class="fas fa-file-alt"></i>
								<span class="title"> Manage Doctors </span>
							</a>
						</li>
					</ul>	
                </li>
				<li>
                    <a href="appointment-history.php"><i class="fas fa-file-alt"></i>  Appointments </a>
                </li>
				<li>
                    <a href="manage-patient.php"><i class="fas fa-file-alt"></i>  Manage Patients </a>
                </li>
				<li>
                    <a href="patient-search.php"><i class="fas fa-search"></i>  Search Patients </a>
                </li>
                
            </ul>
        </nav>